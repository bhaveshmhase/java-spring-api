package com.adapty.product.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adapty.product.Repository.CartRepository;
import com.adapty.product.Repository.ProductRepository;
import com.adapty.product.entities.Cart;
import com.adapty.product.entities.STATUS;
import com.adapty.product.entities.Product;
import java.util.Optional;


@Service
public class CartImpl implements CartInterface {
    @Autowired
     CartRepository repoCart;
     @Autowired
     ProductRepository repoObj;

     public List<Cart> findAllCart(){

        return repoCart.findAll();
    }
    public String AddObjToCart(Cart cartObj){
        Optional<Product> a1 =repoObj.findById(cartObj.getProductId());
        if(a1.get().getProductStatus() == STATUS.ACTIVE){
            repoCart.save(cartObj);
            return "Object created Successfully";
         
        }
        else{
            return "SELECTED PRODUCT STATUS IS INACTIVE";
        }
    }
    @Override
    public String deleteByCartID(String cartItemId){
        repoCart.deleteById(cartItemId);
        return "Cart object deleted successfully";
  
    
    }
    public Cart updateCartByItemId(Cart cartItemId){
        if(cartItemId.getCartItemId() == null){
            return cartItemId;
        }
        else{
            Optional<Cart> c1 = repoCart.findById(cartItemId.getCartItemId());
    
            
            c1.get().setCartItemQty(cartItemId.getCartItemQty());
            c1.get().setCartItemId(cartItemId.getCartItemId());
            c1.get().setProductId(cartItemId.getProductId());
          
    
            repoCart.deleteById(cartItemId.getCartItemId());
            return repoCart.save(c1.get());
        }
    }
    public String deleteCartByProductId(String productId){
        repoCart.deleteByProductId(productId);
        return "Product Id in cart deleted successfully.";
    }

        
        
    }


   
    
    

