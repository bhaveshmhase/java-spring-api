package com.adapty.product.entities;

public enum CATEGORY{
    ELECTRONICS,
    CLOTHES,
    TOYS
}