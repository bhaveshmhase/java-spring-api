package com.adapty.product.entities;
public enum STATUS{
    ACTIVE,
    INACTIVE
}