package com.adapty.product.Repository;
import java.util.List;

import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.adapty.product.entities.Cart;
import com.adapty.product.entities.Product;


public interface CartRepository extends JpaRepository<Cart,String>{
    @Transactional
    public String deleteByProductId(String productId);

    public List<Cart> findById(List<Product> findAllById);


    
}
